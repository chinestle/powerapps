# Shilpa Trainee Insights (slim) — Power BI Desktop September 2023 or newer

Queries: ShilpaClean (helper, not loaded) · Trainees · Cluster
Pages: Overview · Workforce · Pipeline · People

## Open the project (.pbip)
1. File > Options and settings > Options > Preview features > tick "Power BI Project (.pbip) save option", restart.
2. Unzip into a new empty folder and open "Shilpa Trainee Insights.pbip".
3. Transform data > ShilpaClean > Advanced Editor > change the FilePath line at the top to your Excel path > Done.
4. Close & Apply.

## Supervisor feature
- "Supervisor" comes from the Supervisor's email column (name only, the address is not loaded).
  Trainees with no supervisor e-mail show as "Not assigned".
- Overview: Trainees per Supervisor bar (click a bar to filter the page).
- Workforce: Supervisor Load matrix (click + to see each supervisor's trainees) and a separate Line Manager chart.
- Every page has a Supervisor filter at the top.
