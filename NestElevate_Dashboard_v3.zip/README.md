# NestElevate Training Dashboard v3: plan-based, profile model

## What's in this package

| File | Purpose |
|---|---|
| `Power BI/Nest Elevate Training Dashboard.pbit` | **Template (recommended).** Double-click it, choose the data source, then Load. |
| `Power BI/Nest Elevate Training Dashboard.pbip` (+ folders) | The same dashboard as a Power BI Project. Needs Desktop June 2023 or later with the PBIP preview feature enabled. |
| `Data Upload Template v2.xlsx` | Your upload sheet plus one new column: **Employee Group (BC / WC)** |
| `TrainingMap_Import_and_Plan_Reference.xlsx` | The plan in readable form: all 245 trainings with exact names, the section rules (including black = not applicable) and the name aliases. Import the first sheet into the SharePoint Training Map, so the Power App only offers correct names. |
| `Previews/` | All 6 pages, drawn from your 2025 sample data |
| `Power BI/Rebuild kit/` | All Power Query and DAX code, plus the theme |

## How completion is measured now

The **yearly plan** is built into the dashboard from the 2026 KF Training Progress workbook. It is the same every year.

| Plan part | Who must take it | Rule |
|---|---|---|
| BC Mandatory 1–22 | Every BC employee | A black cell means not applicable for that section. Departments without a column (QA, Engineering, HR, Supply Chain, Procurement, AG, SHE, ME, Finance) take all 22. |
| PG I programme (77) | PG I employees, by section | Beverage manufacturing → VBD. Filling common → Beverage F&P, Milk F&P, VM F&P. Bouillon, Noodle, Area Engineering → PG I Plant Engineering. |
| PG II programme (122) | PG II employees, by section | EVM, VM → Vending Mix, Egron, Niro, PG2 Area Engineering → PG II Plant Engineering. UHT has no programme sheet, so it gets BC Mandatory only. |
| WC Mandatory (8) | WC employees only | Employee Group = WC |
| Other trainings 23–38 | Team-specific | Tracked as conducted / not yet, sessions and participants. Not counted in completion %. |

For every employee and year the dashboard creates the list of **required trainings**. It then ticks each one **completed** when the Data Upload contains a *Completed* row for that employee, matched by training name or alias.

* **Plan completion %** = completed required trainings ÷ required trainings, for the selected year. With no year selected, it uses the current year.
* **Session** = one training module + one trainer + one date.
* **Session hours delivered** = the duration counted once per session, not once per person. Pasindu, for example, is 10 sessions and 26 hours in 2025.
* **Participations / person-hours** are shown separately and clearly labelled.

## Your 2025 sample data

| | Result |
|---|---|
| Sessions conducted | 259 |
| Session hours delivered | 455.2 |
| Participations | 3,894 |
| Plan completion | 9.5% |
| Uploads matched to the plan | 40% |

Plan completion is low because most 2025 module names differ from the plan names. The **Other & Check** page lists every unmatched name.

For 2026 uploads: use the exact plan names in *Allocated Module*. They are in the reference workbook, and if you import it, in the Power App dropdown. If you have recurring names that differ, add them to the alias table: *Transform data → PlanAliases → Source* (gear icon).

## Opening the template (.pbit)

1. Double-click **Nest Elevate Training Dashboard.pbit**.
2. A parameter box opens:
   * **SourceMode = SharePoint List**: live data from `nelevate_TrainingAllocation`. Sign in with your organizational account.
   * **SourceMode = Excel File**: set `ExcelFileLocation` to the full path of a Data Upload file.
3. Click **Load**, then **Save as .pbix** and **Publish**.
4. To refresh automatically after each upload, add **Power BI → Refresh a dataset** at the end of the two upload flows.

## Pages

1. **Factory**: plan completion year to date, required / completed / pending, sessions, session hours; monthly cumulative completion (azure) vs session hours (coral) with the 90 % target (cobalt); completion by department and by plan group; the most-pending trainings.
2. **Department**: all 11 departments: completion vs session hours, a department × plan-group heat map, and a scorecard.
3. **Section**: the **BC Mandatory matrix rebuilt live**, showing % of employees completed per training × section. Green ≥ 90 %, amber 50–90 %, red < 50 %, blank = not applicable. It also has a section league table and the section programme status.
4. **Employee**: every employee's required, completed and pending trainings. Click an employee to see their personal training list with status.
5. **Trainers**: sessions, session hours, participants and modules per trainer, and sessions by module.
6. **Other trainings & data check**: team trainings (conducted or not), uploaded names not found in the plan, and rows missing an employee number.

## Known limits

* **Headcount**: in Excel mode only employees who appear in uploads are counted. In SharePoint mode, staff in the Employee Master list who have no uploads are also counted, as 0 % complete.
* **BC / WC**: everyone is treated as BC unless the upload has Employee Group = WC.
* **Co-delivered sessions**: a session delivered by two trainers on the same day counts once per trainer.

## v3: profile model (no repeated employee rows)

An employee's yearly trainings depend only on their **profile**, so the dashboard no longer copies the training list for every person:

| Profile | Trainings |
|---|---|
| BC – [section] | applicable BC mandatory + that section's PG programme. Examples: Noodle 34, Egron 59, Niro 57, UHT 19, VBD 35. |
| BC – General | all 22 BC mandatory (QA, Engineering, HR, Supply Chain, Procurement, AG, SHE, ME, Finance, PG I/II General) |
| WC | the 8 WC trainings |

| Table | Rows | Source |
|---|---|---|
| ProfileRequirements | 500 (fixed) | Built into the model. Listed in the *Profile requirements* sheet of the reference workbook. |
| DimEmployee | one per person | Calculated from uploads (+ Employee Master): latest section, group and profile |
| Completions | one per employee × plan training × year completed | Calculated from uploads |
| Attendance | upload rows | SharePoint list (downloaded **once**) |

* **Required trainings** = employees per profile × trainings in that profile, so no per-employee rows are stored.
* **Completed** = completions whose training belongs to the employee's profile.
* **Results:** identical to v2 on your 2025 data (17,991 required, 1,715 completed, 9.5%), using 2,587 completion rows instead of 35,982 requirement rows.
* **Refresh:** downloads the allocation list once (plus the small Employee Master list in SharePoint mode). Everything else is calculated inside Power BI.
* **To change the plan:** edit *ProfileRequirements* (Transform data → ProfileRequirements → Source) or *DimTraining*.
