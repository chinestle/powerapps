# Shilpa Trainee Insights — Power BI Project (PBIP), Nordic Pastel edition

## Open it
1. Power BI Desktop, September 2023 or newer. In 2023 builds turn on
   *File › Options and settings › Options › Preview features › Power BI Project (.pbip) save option*, then restart Desktop.
2. Unzip into a new, empty folder.
3. Open `Shilpa Trainee Insights.pbip`.
4. *Transform data › Edit parameters › FilePath* → full path of `Shilpa_Database_4.xlsx` (default `C:\Shilpa\Shilpa_Database_4.xlsx`), then **Refresh**.

## Pages
| Page | Contents |
|---|---|
| Overview | 7 KPI cards, 5 status cards with share bars, rounded pill 100% stacked bars (status mix per production cluster), stepped headcount line |
| Workforce | Native 100% stacked bar (status mix by department), cluster load, span of control, phase donut, section × department heat grid |
| Pipeline | Monthly intake / expiry / absorption, stepped allowance outlook, days-to-expiry per trainee, status donut, contract length |
| People | Age, gender, A/L year, feeder schools, home towns |
| Data Quality | Coverage of 17 key fields, issues by type, issue log |
| Roster | Every trainee with a soft status pill and record-completeness bar |

## Design system (theme: Report/StaticResources/RegisteredResources/ShilpaNordic.json)
Warm Sand page #EAE7DC · Card #F8F7F2 · Forest #2D6A4F · Sage #74C69D · Ochre #E9D8A6 · Slate #2B2D42
(+ muted clay #C08552 for "expired", stone #A8A29E for "dates pending").
16 px rounded cards, 1 px #D6D3D1 borders, 20 px padding, faint 2 px shadow, Segoe UI,
dotted #E2E8F0 horizontal gridlines, Y-axis hidden, data labels instead.

## Data rules
Power Query `ShilpaClean`: department / manager / school normalisation, Excel serial and text dates fixed,
Sri Lankan NIC decoded to recover missing birth dates and gender, status computed as of refresh date.
NIC, phone, address and e-mail values are not loaded into the model.
