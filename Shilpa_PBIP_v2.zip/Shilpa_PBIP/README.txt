SHILPA TRAINEE DASHBOARD - Power BI Project (PBIP), compatible with Power BI Desktop Sept 2023 and newer

OPEN
1. Power BI Desktop > File > Options and settings > Options > Preview features:
   tick 'Power BI Project (.pbip) save option' (you already have PBI_gitIntegration on). Restart.
2. Unzip, then File > Open report > Browse this device > Shilpa.pbip
3. Home > Transform data > Edit parameters: set FilePath to your Excel file path
   (e.g. C:\Users\you\Downloads\Shilpa.xlsx). Close & Apply, then Refresh.

MODEL
Trainees (cleaned; NIC, DOB, address, phone, emails removed, Age derived), Calendar,
one relationship (Trainees[Appointed Date] -> Calendar[Date]) and 8 measures.

BUILD VISUALS
Cards: Total Trainees, Total Monthly Allowance, Absorption Rate %, Expiring in 60 Days.
Donut: Phase, Gender. Bar: Section, Line Manager. Matrix: Section x Phase with allowance.
Line chart: Calendar[Month] vs Total Trainees. Slicers: Phase, Section, Grade, Line Manager.
Then File > Save as to get a .pbix.

HR data: use Row-Level Security and get approval before publishing.
