KPI HUB - HR DATA (updated)
===========================
HR Head: Saman Priyankara (saman.priyankara@lk.nestle.com). He has no KPIs and sees all data in the app.

1_GoLive_real_KPIs   <- USE THIS FOR THE REAL LISTS
  HR_KPI_Library.csv      the 24 real HR KPIs
  HR_KPI_Assignments.csv  24 assignments (Dhanushka, Duminda, Ishan, Chirathni).
                          Latest values are blank and status is "No Update" until people enter results.
  HR_KPI_Progress.csv     header row only (empty). Each employee fills it from the app's
                          "Update progress" screen, month by month (Jan-Dec).

2_TestData_real_KPIs_with_sample_results   <- only for trying the app
  Same KPIs, with sample monthly results Jan-Oct, reviewed by Saman.

HOW TO LOAD
  1. In SharePoint, create each list from its CSV (New > List > From CSV),
     named exactly like the file (HR_KPI_Library, HR_KPI_Assignments, HR_KPI_Progress).
  2. If you've already loaded the test data, delete those lists (or their rows) and reload from the go-live folder.
  3. Make sure Saman's row is in HR_Employees with AppRole = "HR Head".
