SHILPA TRAINEE DASHBOARD - Power BI Project (PBIP)

WHAT IS IN HERE
- Shilpa.SemanticModel : cleaned Trainees table (Power Query), Calendar table,
  relationship, and 8 DAX measures. Personal data (NIC, DOB, address, phone,
  emails) is removed in the load step; only a derived Age is kept.
- Shilpa.Report        : empty report linked to the model. Build visuals here.

HOW TO OPEN
1. Power BI Desktop > File > Options and settings > Options > Preview features
   > tick "Power BI Project (.pbip) save option". Restart Power BI Desktop.
2. Unzip this folder, then File > Open report > Browse this device,
   pick Shilpa.pbip.
3. When prompted (or via Home > Transform data > Edit parameters), set the
   FilePath parameter to your Shilpa Excel file, e.g. C:\Data\Shilpa.xlsx.
   Excel date columns should be real dates or serial numbers; the NIC column
   is not loaded.
4. Click Refresh. Check the Data view: Trainees should show Grade, Section,
   Phase, Allowance, dates and Age.

BUILD THE REPORT
Add visuals using the measures in the Trainees table:
- Cards: Total Trainees, Total Monthly Allowance, Absorption Rate %, Expiring in 60 Days
- Donut: Phase and Gender by Total Trainees
- Bar: Section and Line Manager by Total Trainees
- Matrix: Section x Phase with Total Monthly Allowance
- Table: Name, Section, Line Manager, Phase, Training Expiry Date
- Line/column: Calendar[Month] with Total Trainees (Appointed Date relationship)
- Slicers: Phase, Section, Grade, Line Manager
Then File > Save as .pbix if you want a single file to share.

IF THE MODEL FAILS TO LOAD
PBIP is a preview format and tolerates little deviation. If Power BI reports a
TMDL error, tell me the exact message and I will fix the file. As a fallback,
use the Power Query script from the chat (Advanced Editor) and add the
measures manually.

PRIVACY
This is HR data. Do not publish to a shared workspace without Row-Level
Security and approval from HR/data owner.
